function validation()
{
	var fname=document.getElementById("fname").value;
	var lname=document.getElementById("lname").value;
	var pwd=document.getElementById("password").value;
	var cpwd=document.getElementById("pwd").value;
	var mno=document.getElementById("mobileno").value;
	var email=document.getElementById("email").value;
	var reg1=/^[a-zA-Z]+$/;
	var reg2=/^[a-zA-Z]+$/;
	var regp=/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/;
	var regmno=/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
	var emailexp = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
	if(!reg1.test(fname))
	{
		alert("Enter Only Characters for First Name:");
		fname.value="";
		fname.focus();
		return false;
	}
	if(!reg2.test(lname))
	{
		alert("Enter Only Characters for Last Name:");
		lname.value="";
		lname.focus();
		return false;
	}
	if(!regp.test(pwd))
	{
		alert("Enter valid password:");
		password.value="";
		password.focus();
		return false;
	}
	 if(pwd!=cpwd)
	{
		alert("password & confirm password field must be same:");
	}
	 if(!regmno.test(mno))
	{
		alert("Enter phone no in xxx-xxx-xxxx or xxx.xxx.xxxx or xxx xxx xxxx format:");
		mobileno.value="";
		mobileno.focus();
		return false;
	}
	 if(!emailexp.test(email))
	{
		alert("Enter Valid Email:");
		email.value="";
		email.focus();
		return false;
	}
	 if(document.f1.r1.checked==false && document.f1.r2.checked==false)
	 {
		 alert("please choose gender:");
		 return false;
	}
		return true;
}
/*function time()
{
	  setTimeout("time()",180000);
	  alert("Fill the form within 3 min:");
}*/
